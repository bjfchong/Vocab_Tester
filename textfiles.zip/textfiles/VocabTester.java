//Max choice

///Technical Issues
//make variables public
//add gui?
//sort out "both"
//check when entering word that it's not empty
//compare words with one letter out of first and then out of second using arrays

///"View Word Sets"
//Display worst words
//display words by success
//Show some % for each list - decays over time?

///"Add Words"
//create new wordset
//edit words: delete/add word sets, delete/add words
//check list to see if exists
//does it add accents? - no.

///Wrong Words
//when displaying wrong words, put in order of language (for both)
//redoing wrong words doesn't show a score

///Question Frequency
//take x worst questions and use those?/strengthen selection bias
//frequency curves
//frequency of question based on percentage and number of times been shown? ie 3/3 before 9/10.
//Recent questions wrong more frequent

///Answering Questions
//compare strings without spaces
//display the desired string with accents
//allowing shorter 1 strings to be accepted as correct
//shuffle re-do array
//shorter answers being accepted - needs fixing

///Hints
//change verb hints to auto include "to" + not count spaces
//if right on hint don't add to score or appearances
//problems with 100% hint perc


///Settings
//settings with option for:number of hints allowed, frequency curves
//hotkeys for exit and menu and settings?



package textfiles;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.math.*;
import java.io.File;



public class VocabTester {	

public static int hintNum = 0;
public static int hintPerc = 0;
public static int correctCount = 0;
public static int wrongCount = 0;
public static int weakerThreshold = 5;
public static int weakerFrequency = 20;
protected static String[] specCharArray;

//operation shuffleArray shuffles the order of the array or integers
//into a random order
	static void shuffleArray(int[] ar) {
	
		Random rnd = ThreadLocalRandom.current();
    
		for (int i = ar.length - 1; i > 0; i--) {
    
			int index = rnd.nextInt(i + 1);
			int a = ar[index];
			ar[index] = ar[i];
			ar[i] = a;
		}
	}
	//Clears Screen in java
	public static void clrscr(){
    
    try {
        if (System.getProperty("os.name").contains("Windows"))
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        else
            Runtime.getRuntime().exec("clear");
    } catch (IOException | InterruptedException ex) {}
	System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
	System.out.println("");
}
	static void loadSpecialChars(){
		String file_name =  System.getProperty("user.dir") + "/textfiles/specialChars.txt";
		try{
			ReadFile file = new ReadFile(file_name);
			specCharArray = file.OpenFile();							
		} catch (IOException e){
			System.out.println(e.getMessage());	
		}
	}
	//calls for entry, exits if equals exit
	static String callExit(){
		Scanner call = new Scanner(System.in);
		String input = call.nextLine();
		
		if (capsEqual("exit",input) == true) {
			System.exit(0);
		}
		if ((capsEqual("menu",input) == true) || (capsEqual("main",input) == true)) {
			clrscr();
			System.out.println(" ");
			firstMenu();
		}
	
		return input;
		
	}
	//enumerates list
	static void enumerateList (String[] list){
		for (int l=0;l<list.length;l++) {
			list[l] = list[l].substring(0, list[l].length());
			System.out.println("(" + (l + 1) + ") " + list[l]);
		}
	}
	//enumerates list of filenames	
	static void enumerateFileList(String[] list) {
		for (int i=0;i<9;i++) {
			list[i] = list[i].substring(0, list[i].length()-4);
			System.out.println("(" + (i + 1) + ")  " + list[i]);
		}
		for (int l=9;l<list.length;l++) {
			list[l] = list[l].substring(0, list[l].length()-4);
			System.out.println("(" + (l + 1) + ") " + list[l]);
		}
		System.out.println(" ");
	}
	//limits the number of new words put into a test
	static Word[] limitNewWords(Word[] ogArray, String lang){
		
		Word[] oldArray = new Word[ogArray.length];
		Word[] newArray = new Word[weakerFrequency];
		
		for (int l = 0;l<newArray.length;l++){
			newArray[l] = new Word(0,0,0,0,"null","null","null","null");
		}
		
		
		if (lang.equals("1")) {
			
			int q = 0;
			for(int p = 0;p<ogArray.length;p++){
				if (ogArray[p].getEss() >= weakerThreshold){
					oldArray[q] = ogArray[p];
					q++;
				}
			}
			
			int y = 0;
			for(int x = 0;x<ogArray.length;x++){
				if (ogArray[x].getEss() < weakerThreshold){
					newArray[y] = ogArray[x];
					y++;
					if (y == weakerFrequency){
						x = ogArray.length;
					}
				}
			}
			
			Word[] product = new Word[y + q];
			
			for(int j = 0;j<q;j++){
				product[j] = oldArray[j];
			}
			for(int k = 0;k<y;k++){
				if (capsEqual(newArray[k].getEng1(),"null") == false){
					product[k+q] = newArray[k];
				}
				
			}
			
			return product;
		}	
		
		if (lang.equals("2")) {
			
			int q = 0;
			for(int p = 0;p<ogArray.length;p++){
				if (ogArray[p].getSes() >= weakerThreshold){
					oldArray[q] = ogArray[p];
					q++;
				}
			}
			
			int y = 0;
			for(int x = 0;x<ogArray.length;x++){
				if (ogArray[x].getSes() < weakerThreshold){
					newArray[y] = ogArray[x];
					y++;
					if (y == weakerFrequency){
						x = ogArray.length;
					}
				}
			}
			
			Word[] product = new Word[y + q];
			
			for(int j = 0;j<q;j++){
				product[j] = oldArray[j];
			}
			for(int k = 0;k<y;k++){
				if (capsEqual(newArray[k].getEng1(),"null") == false){
					product[k+q] = newArray[k];
				}
			}
			
			return product;
		}
		
		return null;
	}
	
	//checks to see if word is already in list 
	static boolean checkList(String enteredWord, Word[] totalWords, int lang) {
		if (lang < 1) {
			
			for (int i = 0;i<totalWords.length;i++){
				if (capsEqual(totalWords[i].getSpa1(),enteredWord) == true) {
				
					System.out.println(" ");
					return true;
				}
			}
		}
		
		if (lang > 0) {
			
			for (int i = 0;i<totalWords.length;i++){
				if (capsEqual(totalWords[i].getEng1(),enteredWord) == true) {
					
					System.out.println(" ");
					return true;
				}
			}
		}
		return false;
	}
	//check whether words are equals not caps sensitive
	static boolean capsEqual (String storedAns, String typedAns){
		boolean truth = false;
		
		int errorNum = 0;

		
		int slashNum = 0;
		String[] storedChars = storedAns.split("(?!^)");
		String[] typedChars = typedAns.split("(?!^)");
		
		try{
			for (int i=0;i<typedChars.length;i++){
				if (typedChars[i].equals("/")) {
					slashNum++;
					if (typedChars[i+1].toLowerCase().equals("a") == true) {
						typedChars[i+1] = specCharArray[0];
					} else if (typedChars[i+1].toLowerCase().equals("e")) {
						typedChars[i+1] = specCharArray[1];
					} else if (typedChars[i+1].toLowerCase().equals("i")) {
						typedChars[i+1] = specCharArray[2];
					} else if (typedChars[i+1].toLowerCase().equals("o")) {
						typedChars[i+1] = specCharArray[3];
					} else if (typedChars[i+1].toLowerCase().equals("u")) {
						typedChars[i+1] = specCharArray[4];
					} else if (typedChars[i+1].toLowerCase().equals("n")) {
						typedChars[i+1] = specCharArray[5];
					} else {
						errorNum++;
					}
					i++;
				}

			}
			
		String[] editedChars = new String[typedChars.length - slashNum];
		
		int j = 0;
		String ans = "";
		for (int k = 0;k<typedChars.length;k++){
			if (typedChars[k].equals("/")==false) {
				
				ans = ans + typedChars[k];
			} 
		}
			
			if (ans.equals(storedAns)){
				truth = true;
			} else {
				truth = false;
			}
		
			return truth;
		
		} catch (ArrayIndexOutOfBoundsException  e){
			truth = false;
					
		}
		
	return truth;
	}
	//changes hint percentage
	static int hintPercentage(){
		System.out.println("Type in new hint percentage:");
		boolean hintPerc = false;
		System.out.println(" ");
		
		while (hintPerc == false) {
			
			String perc = callExit();
			System.out.println(" ");
			
			try{
				if (-1 < Integer.valueOf(perc) && Integer.valueOf(perc) < 101) {	
					hintPerc = true;
					return Integer.valueOf(perc);
				}	
			}
			catch(Exception e){
				System.out.println("Please choose a number between 0 and 100:");
				System.out.println(" ");
			}
		}
		return 5;
	}
	//repeats wrong questions
	static void repeatWrongs(Word[] array, String language) {
		System.out.println("Repeat wrong answers?");
		
		boolean validChoice = false;
		
		while (validChoice == false) {
			
			String response = callExit();
			System.out.println(" ");
			
				if ((capsEqual(response,"y") == true) || (capsEqual(response,"yes") == true)) {
					correctCount= 0;
					hintNum = 0;
					
					clrscr();
					
					for (int i =0;i<wrongCount;i++){
						
						boolean correct = giveQuestion(language,array,i);
					}
					validChoice = true;
					break;	
				} else if ((capsEqual(response,"n") == true) || (capsEqual(response,"no") == true)) {
						
					validChoice = true;
					break;	
				} else {
					System.out.println("Please choose Y or N"); 
				}			
		}
	}
	//scans settings file and updates the global variables
	static void scanSettings() {
		String settingsLoc =  System.getProperty("user.dir") + "/textfiles/settings.txt";
	
			try{
				ReadFile file = new ReadFile(settingsLoc);
				String[] loadSettings = file.OpenFile();			
				loadSettings[0] = loadSettings[0].substring(17, loadSettings[0].length()-1);
				hintPerc = Integer.valueOf(loadSettings[0]);
			} catch (IOException e){
				System.out.println(e.getMessage());	
			}
		
		
	}
	//operation to choose files from the names in vocab folder
	public static String getFileName() {
		
		String wordSet = "null"; 
		String file = " ";
		
		File folder = new File(System.getProperty("user.dir") + "/textfiles/Vocab");
		File[] listOfFiles = folder.listFiles();
		String[] fileNames = new String[listOfFiles.length];
		System.out.println("Choose a word set:");
		System.out.println("");
		for (int i = 0; i < listOfFiles.length; i++) {
			fileNames[i] = listOfFiles[i].getName();
		}

		enumerateFileList(fileNames);
		
		boolean validWordSet = false;
		
		System.out.println(" ");
		
		while (validWordSet == false) {
			
			wordSet = callExit();
			System.out.println(" ");
			
			for (int l=0; l < listOfFiles.length; l++) {
			String comparison = String.valueOf(l+1);

				if (capsEqual(wordSet,comparison) == true) {
						
					validWordSet = true;
					file =  System.getProperty("user.dir") + "/textfiles/Vocab/" + fileNames[l] + ".txt";
					break;	
				}
			}	
			
			if (validWordSet == false) {
				System.out.println("Please choose a number between 1 and " + (listOfFiles.length) +":");
				
			} else {
				break;
			}

		}
		System.out.println(" ");
		clrscr();
		return file;
	}
	
	//operation to get language direction of test
	public static String getLanguage() {
		String L = "null"; 
		
		boolean validLanguage = false;
		
		while (validLanguage == false) {
			
			System.out.println("Choose a language option:");
			System.out.println("(1) English to Spanish");
			System.out.println("(2) Spanish to English");
			System.out.println("(3) Both");
			System.out.println(" ");

			L = callExit();
			System.out.println(" ");
				
			if (capsEqual("English to Spanish",L) == true || capsEqual("1",L) == true){
				L = "1";
				break;
			} else if (capsEqual("Spanish to English",L) == true||capsEqual("2",L) == true){
				L = "2";
				break;
			} else if (capsEqual("Both",L) == true||capsEqual("3",L) == true){
				L = "3";
				break;
			}
				
		}
		clrscr();
		return L;
	}
	//asks for a number or string for the menu option
	//takes the list of option strings in an array
	public static int getMenuOption(String[] list) {
		
		int opt = 0;
		while (opt == 0) {
			String firstMenuAns = " ";
			System.out.println("");
			firstMenuAns = callExit();

			System.out.println("");
			
			for (int p = 0; p < list.length;p++){
				if (capsEqual(Integer.toString(p+1),firstMenuAns) == true || capsEqual(list[p],firstMenuAns) == true) {	
					opt = p+1;	
				}					
			}
			
			if (opt > 0) {
				break;
			}
			
			System.out.println("Please choose a menu option or number");
			System.out.println("");
				
			}
				
		
		return opt;
	}
	//operation to get number of questions of test
	public static int getQueNum(Word[] totalWords) {
		
		
		int testLength = 0;		
		boolean inputCorrect = false;	
			
		while (inputCorrect == false) {
								
			System.out.println("How many questions would you like in the test?");
			System.out.println("");
				
			String first_input = callExit();
			
			try {
				int op1 = Integer.parseInt(first_input);
				
				if (op1 <= totalWords.length) {
					inputCorrect = true;
					testLength = op1;	
				}else{
					inputCorrect = false;
					System.out.println("");				
					System.out.println("Number of questions needs to be less than or equal to " + totalWords.length);
					System.out.println("");
				}
				
			} catch (NumberFormatException e) {
				System.out.println("");				
				System.out.println("This is not an integer");
				System.out.println("");
				inputCorrect = false;	
			}	
		}
		clrscr();
		return testLength;
	}

	//operation to get weightOccurenceSe	
	public static int getWeightSe(Word[] arr) {
		
		int weightOccurenceLength = 0;
		
		for (int j=0; j<arr.length;j++) {
				
				int ses = arr[j].getSes();
				
				if (ses == 0) {
					weightOccurenceLength = weightOccurenceLength + 120;
				}
				if (ses == 1) {
					weightOccurenceLength = weightOccurenceLength + 60;
				}
				if (ses == 2) {
					weightOccurenceLength = weightOccurenceLength + 40;
				}
				if (ses == 3) {
					weightOccurenceLength = weightOccurenceLength + 30;
				}
				if (ses == 4) {
					weightOccurenceLength = weightOccurenceLength + 24;
				}
				if (ses == 5) {
					weightOccurenceLength = weightOccurenceLength + 20;
				}
				if (ses == 6) {
					weightOccurenceLength = weightOccurenceLength + 15;
				}
				if (ses == 7) {
					weightOccurenceLength = weightOccurenceLength + 12;
				}
				if (ses == 8) {
					weightOccurenceLength = weightOccurenceLength + 10;
				}
				if (ses == 9) {
					weightOccurenceLength = weightOccurenceLength + 8;
				}
				if (ses == 10) {
					weightOccurenceLength = weightOccurenceLength + 6;
				}
				if (ses == 11) {
					weightOccurenceLength = weightOccurenceLength + 5;
				}
				if (ses == 12) {
					weightOccurenceLength = weightOccurenceLength + 4;
				}
				if (ses == 13) {
					weightOccurenceLength = weightOccurenceLength + 3;
				}
				if (ses == 14) {
					weightOccurenceLength = weightOccurenceLength + 2;
				}	
				if (ses >= 15) {
					weightOccurenceLength = weightOccurenceLength + 1;
				}					
			}
			
			return weightOccurenceLength;
	}

	//operation to get weightOccurenceSe	
	public static int getWeightEs(Word[] arr) {
		
		int weightOccurenceLength = 0;
		
		for (int j=0; j<arr.length;j++) {
				
				int ess = arr[j].getEss();
				
				if (ess == 0) {
					weightOccurenceLength = weightOccurenceLength + 120;
				}
				if (ess == 1) {
					weightOccurenceLength = weightOccurenceLength + 60;
				}
				if (ess == 2) {
					weightOccurenceLength = weightOccurenceLength + 40;
				}
				if (ess == 3) {
					weightOccurenceLength = weightOccurenceLength + 30;
				}
				if (ess == 4) {
					weightOccurenceLength = weightOccurenceLength + 24;
				}
				if (ess == 5) {
					weightOccurenceLength = weightOccurenceLength + 20;
				}
				if (ess == 6) {
					weightOccurenceLength = weightOccurenceLength + 15;
				}
				if (ess == 7) {
					weightOccurenceLength = weightOccurenceLength + 12;
				}
				if (ess == 8) {
					weightOccurenceLength = weightOccurenceLength + 10;
				}
				if (ess == 9) {
					weightOccurenceLength = weightOccurenceLength + 8;
				}
				if (ess == 10) {
					weightOccurenceLength = weightOccurenceLength + 6;
				}
				if (ess == 11) {
					weightOccurenceLength = weightOccurenceLength + 5;
				}
				if (ess == 12) {
					weightOccurenceLength = weightOccurenceLength + 4;
				}
				if (ess == 13) {
					weightOccurenceLength = weightOccurenceLength + 3;
				}
				if (ess == 14) {
					weightOccurenceLength = weightOccurenceLength + 2;
				}	
				if (ess >= 15) {
					weightOccurenceLength = weightOccurenceLength + 1;
				}					
			}
			
			return weightOccurenceLength;
	}
	//creates questions
	//returns whether the question was correctly answered or not
	public static boolean giveQuestion(String lang, Word[] test, int pos) {
	
	clrscr();
	
	
	boolean complete = false;
	
		if (capsEqual("1",lang) == true){
			System.out.println("------------------------------------------------------------------------");
			System.out.println("What is the Spanish for:                       Score: " + correctCount + "/" + pos + " (" + test.length + ")");
			
			String ansSpaLine = test[pos].getEng1() + "?";				
			for (int i = 0;i < 46 - test[pos].getEng1().length(); i++) {
				ansSpaLine = ansSpaLine + " ";
			}
			ansSpaLine = ansSpaLine + "Hints: " + hintNum;
			
			System.out.println(ansSpaLine);
			System.out.println(" ");
			
			String answer;

			while (complete == false) {
			
				answer = callExit();
				System.out.println("");
				
				if (capsEqual("hint",answer) == true) {
					if (hintNum > 0) {
						hint(test[pos].getSpa1());
						hintNum--;
					} else {
						System.out.println("No hints remaining");
					}
					System.out.println(" ");
				} else if (capsEqual(test[pos].getSpa1(),answer) == true ) {
					System.out.println("*Correct*");
					System.out.println("");
					waiter();
					return true;
				} else {
					System.out.println("*Incorrect*");
					System.out.println("Correct answer: " + test[pos].getSpa1());
					System.out.println("");
					waiter();
					return false;
				}
			}
			
		} else if (capsEqual("2",lang) == true) {
			System.out.println("------------------------------------------------------------------------");
			System.out.println("What is the English for:                       Score: " + correctCount + "/" + pos + " (" + test.length + ")");
			
			String ansEngLine = test[pos].getSpa1() + "?";				
			for (int i = 0;i < 46 - test[pos].getSpa1().length(); i++) {
				ansEngLine = ansEngLine + " ";
			}
			ansEngLine = ansEngLine + "Hints: " + hintNum;
			
			System.out.println(ansEngLine);
			System.out.println(" ");
			
			String answer;
			
			while (complete == false) {
				

				answer = callExit();
				System.out.println("");
					
				if (capsEqual("hint",answer) == true) {
					if (hintNum > 0) {
						hint(test[pos].getEng1());
						hintNum--;
					} else {
						System.out.println("No hints remaining");
					}	
					System.out.println(" ");
				} else if (capsEqual(test[pos].getEng1(),answer) == true ) {
					System.out.println("*Correct*");
					System.out.println("");
					waiter();	
					return true;	
				} else {
					System.out.println("*Incorrect*");
					System.out.println("Correct answer: " + test[pos].getEng1());
					System.out.println("");	
					waiter();
					return false;			
				}
			}
		}
		
		return false;
	}
	
	//operation to create file array
	public static Word[] loadFileArray(String file_name){
		
			try{
				ReadFile file = new ReadFile(file_name);
				String[] aryLines = file.OpenFile();
				Word[] totalWords = new Word[aryLines.length];
			
				for (int i=0; i<aryLines.length;i++) {
			
					String Line = aryLines[i];
				
					String[] sData = Line.split("\\.");
					int[] iData = new int[4];
					iData[0] = Integer.valueOf(sData[0]);
					iData[1] = Integer.valueOf(sData[1]);
					iData[2] = Integer.valueOf(sData[2]);
					iData[3] = Integer.valueOf(sData[3]);
				
					Word create = new Word(iData[0],iData[1],iData[2],iData[3],sData[4],sData[5],sData[6],sData[7]);
			
					totalWords[i] = create;
					
				}
				return totalWords;
			} catch (IOException e){
				System.out.println(e.getMessage());	
			}
		return null;	
	}

	//operation to create weighted array of words
	public static Word[] genTestArray(Word[] arr, String lang) {
		

		
		//gets necessary length of weightOccurence, using weighted frequency
		//depending on score value of word
			
		int weightOccurence = 0;
			
		if (capsEqual("1",lang) == true) {
			weightOccurence = getWeightEs(arr);
		} else if (capsEqual("2",lang) == true){
			weightOccurence = getWeightSe(arr);
		} else if (capsEqual("3",lang) == true){
			weightOccurence = getWeightEs(arr) + getWeightSe(arr);
		}		
		
		Word[] weightOccurenceArr = new Word[weightOccurence];
		int pos = 0;
		int freq = 0;
		
		if (capsEqual("1",lang) == true || capsEqual("3",lang) == true) {
			for (int k=0; k<arr.length;k++){
				
				int ess = arr[k].getEss();
				if (ess == 0) {
					freq = 120;
				}
				if (ess == 1) {
					freq = 60;
				}
				if (ess == 2) {
					freq = 40;
				}
				if (ess == 3) {
					freq = 30;
				}
				if (ess == 4) {
					freq = 24;
				}
				if (ess == 5) {
					freq = 20;
				}
				if (ess == 6) {
					freq = 15;
				}
				if (ess == 7) {
					freq = 12;
				}
				if (ess == 8) {
					freq = 10;
				}
				if (ess == 9) {
					freq = 8;
				}
				if (ess == 10) {
					freq = 6;
				}
				if (ess == 11) {
					freq = 5;
				}
				if (ess == 12) {
					freq = 4;
				}
				if (ess == 13) {
					freq = 3;
				}
				if (ess == 14) {
					freq = 2;
				}	
				if (ess >= 15) {
					freq = 1;
				}	
				
				for(int m=0;m<freq;m++){					
					weightOccurenceArr[pos] = arr[k];
					pos++;
				}
				
			}
		} else if (capsEqual("2",lang) == true || capsEqual("3",lang) == true){
			
			for (int k=0; k<arr.length;k++){
				
				int ses = arr[k].getSes();
				if (ses == 0) {
					freq = 120;
				}
				if (ses == 1) {
					freq = 60;
				}
				if (ses == 2) {
					freq = 40;
				}
				if (ses == 3) {
					freq = 30;
				}
				if (ses == 4) {
					freq = 24;
				}
				if (ses == 5) {
					freq = 20;
				}
				if (ses == 6) {
					freq = 15;
				}
				if (ses == 7) {
					freq = 12;
				}
				if (ses == 8) {
					freq = 10;
				}
				if (ses == 9) {
					freq = 8;
				}
				if (ses == 10) {
					freq = 6;
				}
				if (ses == 11) {
					freq = 5;
				}
				if (ses == 12) {
					freq = 4;
				}
				if (ses == 13) {
					freq = 3;
				}
				if (ses == 14) {
					freq = 2;
				}	
				if (ses >= 15) {
					freq = 1;
				}	
				
				for(int m=0;m<freq;m++){					
					weightOccurenceArr[pos] = arr[k];
					pos++;
				}
				
			}
		}
		
		//creates integer array representing positions of words
		//in the weightOccurence array
		
		int[] intArray = new int[weightOccurence];
			
		for (int l=0;l<weightOccurence;l++){
			intArray[l] = l;
		}
			
		shuffleArray(intArray);
		
		int testLength = getQueNum(arr);
		
		//creates test array of correct size to put the vocabulary in
			
		Word[] testArray = new Word[testLength];
		Word[] possibleArr =  new Word[weightOccurenceArr.length];
		
		int spa = 0;
			
		for (int p=0;p<weightOccurenceArr.length;p++){
			spa = intArray[p];
			possibleArr[p] = weightOccurenceArr[spa];	
					
		}
		
		int posArrPos = 0;
		boolean occured = false;
		
		for (int posi = 0; posi<testArray.length;posi++){
			
			occured = false;
			
			for(int chk = 0; chk < posi; chk++){
				
				if(capsEqual(testArray[chk].getEng1(),possibleArr[posArrPos].getEng1()) == true ){
					posi--;
					occured = true;
					break;
				}
			}
			if (occured == false) {
				testArray[posi] = possibleArr[posArrPos];
			}
			
			posArrPos++;
		}
		
		return testArray;
	}

	//operation to write over original totalArray
	public static Word[] appendTotalWords(boolean fact, Word[] tot, String pos, String lang){
		if (capsEqual("1",lang) == true) {
			if (fact == true) {
				for (int u = 0; u < tot.length; u++){
					if (tot[u].getEng1() == pos){
						tot[u].setEsScore(tot[u].getEss() + 1, tot[u].getEsc() + 1);
					}
				}				
			} else {
				for (int u = 0; u < tot.length; u++){
					if (tot[u].getEng1() == pos){
						tot[u].setEsScore(tot[u].getEss(), tot[u].getEsc() + 1);
					}
				}				
			}
		} else if (capsEqual("2",lang) == true) {
			if (fact == true) {
				for (int u = 0; u < tot.length; u++){
					if (tot[u].getEng1() == pos){
						tot[u].setSeScore(tot[u].getSes() + 1, tot[u].getSec() + 1);
					}
				}				
			} else {
					for (int u = 0; u < tot.length; u++){
					if (tot[u].getEng1() == pos){
						tot[u].setSeScore(tot[u].getSes(), tot[u].getSec() + 1);
					}
				}			
			}			
		}
		
		return tot;
	}

	//operation to write changes to vocab file
	public static void writeChangesToFile(Word[] tot, String file_name){
		try{
			WriteFile data = new WriteFile( file_name , true );
			WriteFile clear = new WriteFile( file_name , false );
				
			clear.writeToFile(tot[0].getWord() );
				
			for (int w=1;w<tot.length;w++) {
						
				data.writeToFile( tot[w].getWord() );
			}
		} catch (IOException e){
				System.out.println(e.getMessage());	
		}
		

	}
	
	//updates the settings file
	public static void updateSettings(String[] newList, String file_name){
		try{
			WriteFile data = new WriteFile( file_name , true );
			WriteFile clear = new WriteFile( file_name , false );
				
			clear.writeToFile(newList[0]);
				
			for (int w=1;w<newList.length;w++) {
						
				data.writeToFile( newList[w] );
			}
		} catch (IOException e){
				System.out.println(e.getMessage());	
		}
				
	}
	
	//starts the test
	public static void startTest() {
		
		String file = getFileName();
		String language = getLanguage();
		Word[] totalWords = loadFileArray(file);
		Word[] slimmedWords = limitNewWords(totalWords,language);
		Word[] testArray = genTestArray(slimmedWords, language);
		
		Word[] wrongArray = new Word[testArray.length];
		int wrongPos = 0;
		correctCount = 0;
		wrongCount = 0;
		
		hintNum = (int)Math.round(testArray.length/10);
		System.out.println(hintNum);
		
		for (int i = 0; i < testArray.length;i++) {			
			String posWordEng1 = testArray[i].getEng1();
			boolean correct = giveQuestion(language,testArray,i);
			if (correct == true) {
				correctCount++;
				totalWords = appendTotalWords(true, totalWords, posWordEng1, language);
			} else if (correct == false) {
				totalWords = appendTotalWords(false, totalWords, posWordEng1, language);
				wrongArray[wrongPos++] = (testArray[i]);
				wrongCount++;
			}
		}
		
		clrscr();
		System.out.println("Wrong Answers:");
		System.out.println("");
		System.out.println("Spanish           English             Spa->Eng        Eng->Spa");
		System.out.println("------------------------------------------------------------------------");
		for (int k = 0; k < wrongPos;k++){
			System.out.println(display(wrongArray[k]));
		}
		System.out.println(" ");
		System.out.println("Final Score: " + correctCount + "/" + testArray.length );
		writeChangesToFile(totalWords, file);
		System.out.println(" ");
		
		
		if (correctCount < testArray.length) {
			repeatWrongs(wrongArray, language);
		} else {
			waiter();
		}
	}
	//hint function, prints 3 random letters of the answer
	public static void hint(String answer){
		String hint = "";
		int l = answer.length();
		
		String[] letters = new String[l];
		int[] showPos = new int[(int)Math.round(((l+1)*hintPerc)/100)];
		boolean alreadyEnt = true;
		
		for (int e=0;e<showPos.length;e++){
			showPos[e] = 0;
		}
		
		for (int j=0; j <showPos.length;j++){
			alreadyEnt = true;
			while (alreadyEnt == true) {
				Random rand = new Random();
				int a = rand.nextInt(l);
				alreadyEnt = false;
				for (int m =0; m < j;m++){
					if (showPos[m] == a){
						alreadyEnt = true;
					}
				}
				if (alreadyEnt == false){
					showPos[j] = a;
				}
			}
		}
		
		for (int f=0;f<l;f++){
			letters[f] = "_";
		}
		
		for (int p=0;p<l;p++){
			for (int y=0;y<showPos.length;y++){
				if (showPos[y] == p){
					char c = answer.charAt(p);
					letters[p] = Character.toString(c);
				}
			}
		}

		for (int v=0;v<l;v++){
			if (Character.toString(answer.charAt(v)).equals(" ")){
				letters[v] = " ";
			}
			
		}
		
		for (int w=0;w<l;w++){
			hint = hint + letters[w];
		}

		System.out.println(hint);
		
	}
	
	//opens the settings
	public static void settings() {
		
		String settingsLoc =  System.getProperty("user.dir") + "/textfiles/settings.txt";
		while("0"=="0") {
			try{
				clrscr();
				ReadFile file = new ReadFile(settingsLoc);
				String[] settingsList = file.OpenFile();
				enumerateList(settingsList);
				int menuInt = getMenuOption(settingsList);	

				if (menuInt == 1){
					int newPerc = hintPercentage();
					hintPerc = newPerc;
					for (int t = settingsList[0].length();t > 17;t--){
						settingsList[0] = settingsList[0].substring(0, settingsList[0].length()-1);
					}
					settingsList[0] = settingsList[0] + newPerc + "%";
					updateSettings(settingsList, settingsLoc);
				} else if (menuInt == 3) {
					firstMenu();
				}
			} catch (IOException e){
				System.out.println(e.getMessage());	
			}
		}
	}
	//first menu
	public static void firstMenu() {
		clrscr();

		String[] menuList =  new String[5];
		menuList[0] = "Start Test";
		menuList[1] = "View Word Sets";
		menuList[2] = "Add Words";
		menuList[3] = "Settings";
		menuList[4] = "Exit";
		
		//Allows response to first menu
		enumerateList(menuList);
		System.out.println("");
		int firstMenuInt = getMenuOption(menuList);	
			if (firstMenuInt == 1){
				clrscr();
				startTest();
			} else if (firstMenuInt == 2) {
				clrscr();
				showWords();
			} else if (firstMenuInt == 3) {
				clrscr();
				addWords();
			} else if (firstMenuInt == 4) {
				clrscr();
				settings();
			} else if (firstMenuInt == 5) {
				System.exit(0);
			}			
		
		
	}
	
	//shows words
	public static void showWords() {
		
		String file = getFileName();
		Word[] totalWords = loadFileArray(file);
		System.out.println("Spanish           English             Spa->Eng        Eng->Spa");
		System.out.println("------------------------------------------------------------------------");
		for (int i=0;i<totalWords.length;i++) {
			System.out.println(display(totalWords[i]) );
		}
		waiter();
	}
	
	//adds words
	public static void addWords() {
		clrscr();
		boolean end = false;
		String file = getFileName();
		
		while (end == false) {
			System.out.println("");
			
			Word[] totalWords = loadFileArray(file);
			
			
			System.out.println("");
			System.out.println("Enter Spanish Word:");
			String span = callExit();
			
			System.out.println("");
			System.out.println("Enter English Word:");
			String eng = callExit();
			
			if ((checkList(span, totalWords, 0) == false) && (checkList(eng, totalWords, 1) == false)){
						
			Word[] newTotal = new Word[totalWords.length + 1];
			
			for (int j = 0; j < totalWords.length;j++){
				newTotal[j] = totalWords[j];
			}
			
			newTotal[newTotal.length - 1] = new Word(0,0,0,0,eng,eng,span,span);
			writeChangesToFile(newTotal,file);
			
			} else {
				System.out.println("Word already in this file");
			}
			
			System.out.println("");
			System.out.println("Would you like to add another word? (Y/N)");
			System.out.println("");
			
			boolean ender = false;
			while(ender == false) {
				String ans = callExit();
				
				if (capsEqual("y",ans) == true||capsEqual("yes",ans) == true){
					break;
				} else if (capsEqual("n",ans) == true||capsEqual("no",ans) == true){
					end = true;
					break;
				} else {
					System.out.println("");
					System.out.println("Please answer Y/N");
					System.out.println("");
				}
			}
		}
	}
	//display
	public static String display(Word spaeng){

		String showSpa = spaeng.getSpa1();
		String showEng = spaeng.getEng1();
		String showSES = spaeng.getSes() + "/" + spaeng.getSec();
		String showESS = spaeng.getEss() + "/" + spaeng.getEsc();
		
		for (int i = 0;i < 20 - spaeng.getEng1().length(); i++) {
			showEng = showEng + " ";
		}
		for (int j= 0;j < 15 - spaeng.getSpa1().length(); j++) {
			showSpa = showSpa + " ";
		}
		
		int sES = String.valueOf(spaeng.getSec()).length() + 1 + String.valueOf(spaeng.getSes()).length();
		
		for (int k = 0; k < (7 - sES); k++ ){
			showSES = showSES + " ";
		}
		
		
		String result = (showSpa + "   " + showEng  + showSES + "         "+ showESS);
		return result;
	}
	//wait command, holds until return is hit, gives delay
	public static void waiter(){
		String wait;
		System.out.println(" ");
		System.out.println("Hit enter to continue");
		wait = callExit();
	}
	//main loop that causes the program to restart
	public static void main(String[] args) throws IOException {
		clrscr();
		scanSettings();
		loadSpecialChars();
		
		int active = 1;
		while (active != 0){
			firstMenu();
		}
	}
}