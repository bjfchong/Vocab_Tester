package textfiles;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;

public class WordReader {
	
	
	
	public static void main(String[] args) throws IOException {
		

		
		
		String file_name = "C:/Users/Ben/Documents/Programming/Vocab/Unit8.txt";
		
		
		
		ReadFile file = new ReadFile(file_name);
		String[] aryLines = file.OpenFile();
		int arraySize = aryLines.length;
		String[] correctForm = new String[arraySize/2];	
		
		int k = 0;
		
		for (int i = 0; i < arraySize - 1; i++) {
			
			correctForm[k] = "0.0.0.0." + aryLines[i+1] + "."  + aryLines[i+1] + "." + aryLines[i] + "." + aryLines[i];
			i++;
			k++;
		}
		WriteFile firstLine = new WriteFile( file_name , false );
		firstLine.writeToFile(correctForm[0]);
		
		WriteFile data = new WriteFile( file_name , true );
		
		for (int j = 1; j < aryLines.length/2; j++) {
		data.writeToFile(correctForm[j]);
		}
	
	}
}