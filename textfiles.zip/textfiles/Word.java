package textfiles;
import java.util.Scanner;

public class Word {

	
	private int esc;
	private int sec;
	private int ess;
	private int ses;
	private String eng1;
	private String eng2;
	private String spa1;
	private String spa2;
	
	// =========================
    // Constructors
    // =========================
	
	 /**
     * Default constructor
     */
	
	public Word() {
		
	}
	
	 /**
     * Alternative constructor, which sets the word with two pairs of integers,
	 * one pair English to Spanish, the other Spanish to English. In the pairs one
	 * integer holds the number of times correctly answered, the other the number 
	 * of times the integer has appeared. The constructor also takes up to 6 strings
	 * 3 for each language.
     *
     * @param esc  English to Spanish count
	 * @param ess  English to Spanish score
	 * @param sec  Spanish to English count
	 * @param ses  Spanish to English score
     * @param eng1 First English word
     * @param eng2 Second English word
	 * @param spa1 First Spanish word
	 * @param spa2 Second Spanish word
     */
	 
	public Word(int ess, int esc, int ses, int sec, String eng1, String eng2, String spa1, String spa2) {
 
		setSeScore(ses,sec);
		setEsScore(ess,esc);
		
		setEng1(eng1);
		setEng2(eng2);
		setSpa1(spa1);
		setSpa2(spa2);
	}
	
	// =========================
    // Setters and Getters
    // =========================
	
	/**
     * Setter - sets the score of the word from Spanish to English.
     *
     * @param nsec  new Spanish to English count
	 * @param nses  new Spanish to English score
     */  
	 
	 public void setSeScore(int nses, int nsec) {
		
		 this.sec = nsec;
		 this.ses = nses;
	 }
	 
	 /**
     * Setter - sets the score of the word from English to Spanish.
     *
     * @param nesc  new English to Spanish count
	 * @param ness  new English to Spanish score
     */  
	 
	 public void setEsScore(int ness, int nesc) {
		
		 this.esc = nesc;
		 this.ess = ness;
	 }
	 
	/**
     * Setter - sets the first english word.
     *
     * @param neng1  new English word
     */  
	 
	 public void setEng1 (String neng1){
	 
		this.eng1 = neng1;
	}
	
	/**
     * Setter - sets the second english word.
     *
     * @param neng2  new English word
     */  
	 
	public void setEng2 (String neng2){
	 
		this.eng2 = neng2;
	}
		
	/**
     * Setter - sets the first Spanish word.
     *
     * @param nspa1  new Spanish word
     */  
	 
	public void setSpa1 (String nspa1){
	 
		this.spa1 = nspa1;
	}
			
	/**
     * Setter - sets the second Spanish word.
     *
     * @param nspa2  new Spanish word
     */  
	 
	public void setSpa2 (String nspa2){
	 
		this.spa2 = nspa2;
	}
	
	/**
     * Getter - gets the Spanish to English count.
     *
     * @return Spanish to English count
     */ 
	 
	public int getSec() {
		 
		 return sec;
	 }
	 
	public int getEsc() {
		 
		 return esc;
	 }
	 
	public int getSes() {
		 
		 return ses;
	 }
	 
	public int getEss() {
		 
		 return ess;
	 }
	
	public String getEng1(){
	 
		return eng1;
	}
	
	public String getEng2(){
	 
		return eng2;
	}
	
	public String getSpa1(){
	 
		return spa1;
	}
	
	public String getSpa2(){
	 
		return spa2;
	}
	
	public String getWord() {
		String S = (ess + "." +esc + "." +ses + "." +sec + "." +eng1 + "." + eng2 + "." + spa1 + "." + spa2 );
		return S;
	}
	
	public String stringWord() {
		String S = ("[" + eng1 + "," + eng2 + "] , [" + spa1 + "," + spa2 + "] E-S Score: (" + ess + "/" + esc + ") S-E Score: (" + ses + "/" + sec + ")");
		return S;
	}
	
	
	
	
	// =======================================================
	// Tester - test methods defined in this class
	// =======================================================
	
	
	public static void main(String args[]) {
        // You need to fill in this method.
		
		Word Hello = new Word(4 ,5 ,3 ,7 ,"Hello","Hi","Hola","Salut");

		String test = Hello.stringWord();
		System.out.println(test);
		
		System.out.println();
		System.out.println("What is the Spanish for " + Hello.eng1 + "?");
		
		String answer = "answer";
		String exit = "exit";
		
		while (!exit.equals(answer)) {
		
		int tess = Hello.ess;
		int tesc = Hello.esc;
		
		Scanner user_input = new Scanner( System.in );
		
		answer = user_input.nextLine();
		
		if (answer.equals(Hello.spa1) || answer.equals(Hello.spa2)) {
			System.out.println("Correct");
			Hello.setEsScore(Hello.ess+ 1, Hello.esc + 1);
			
			tess = Hello.ess;
			tesc = Hello.esc;
			
			System.out.println("(" + tess + "," + tesc +")");
		} else {
			System.out.println("Incorrect");
			Hello.setEsScore(Hello.ess, Hello.esc + 1);
			
			tess = Hello.ess;
			tesc = Hello.esc;
			
			System.out.println("(" + tess + "," + tesc +")");
		}
		}
	}
}